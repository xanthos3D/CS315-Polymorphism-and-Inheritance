//
// Created by Owner on 4/12/2023.
//

#ifndef PROJECT_4_ARTISTS_HPP
#define PROJECT_4_ARTISTS_HPP


#include "Artist.hpp"
#include<vector>
#include<fstream>
#include<cstring>
#include"JSONArray.hpp"
#include "Albums.hpp"
#include "ArtistImage.hpp"
#include "ArtistImages.hpp"


class Artists: public JSONArray
{
public:
    Artists();
    ~Artists();

    int numArtists();
    void addArtist(Artist *artist);
    //Artist *artistWithID(unsigned int aID);
    void loadArtistsFromFile(std::string fileName);
    std::string htmlString();
    // this function is called from the suer class json array
    // so that when we create a artist we can tell the pars json array to down cast json object to our class artist
    JSONDataObject *jsonObjectNode() { return new Artist();  }
    void setAlbumsForArtists(Albums *albums);
    void setImagesForArtists(ArtistImages *);
    std::vector<Artist *> *listOfArtists() { return (std::vector<Artist *> *) _listOfDataObjects; }
    void runAsserts();  // used for checking the integrity of this class.
private:
    // had problems using listOfArtists so i made a second storage containter initilizing artists as there proper object from the jsondata objects.
    // should remove later but for now i am going to format it this way to continue the project.
    //std::vector<Artist *> *_artists;


};

#endif //PROJECT_4_ARTISTS_HPP
