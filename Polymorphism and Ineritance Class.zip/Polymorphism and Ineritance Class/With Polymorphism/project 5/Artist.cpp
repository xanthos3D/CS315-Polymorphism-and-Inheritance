//
// Created by xmani on 4/8/2023.
//

#include "Artist.hpp"
#include<iostream>
#include<string>
#include<cstring>

Artist::Artist(){
    _name = "";
    _realName = "";
    _profile = "";
    _numImages = "";
    _artistID = 0;
    cachedProfile = false;
    cachedArtistID = false;
    cachedName = false;
    cachedNumImages = false;
    cachedRealName = false;
    _primaryImage = nullptr;
    _secondaryImage = nullptr;
}
Artist::~Artist(){

}

std::string Artist::profile(){
    //so we have a jsondataobject. we then need to get the data out of the pair and into the child class
    // if this acessor has already been cashed then return variable stored. other wise cach variable then return.
    if( cachedProfile ){
        return _profile;
    }else{
        // otherwise we search the listofdataItems to see if one of the pairs key attributes match this atribute.
        for(int counter = 0; counter < listOfDataItems()->size(); counter++){
            if(listOfDataItems()->at(counter)->attributeName() == "profile"){
                _profile = listOfDataItems()->at(counter)->stringValue();
                cachedProfile = true;
                return _profile;
            }

        }
        // if we find it then we set cached to true and set _profile to the profile value in that pair.
    }
    std::cout<<" unable to cach data in artist... terminating..."<<std::endl;
    exit(1);

}
std::string Artist::artistName(){
    //so we have a jsondataobject. we then need to get the data out of the pair and into the child class
    // if this acessor has already been cashed then return variable stored. other wise cach variable then return.
    if( cachedName ){
        return _name;
    }else{
        // otherwise we search the listofdataItems to see if one of the pairs key attributes match this atribute.
        for(int counter = 0; counter < listOfDataItems()->size(); counter++){
            if(listOfDataItems()->at(counter)->attributeName() == "artist_name"){
                _name = listOfDataItems()->at(counter)->stringValue();
                cachedName = true;
                return _name;
            }

        }
        // if we find it then we set cached to true and set _profile to the profile value in that pair.
    }
    std::cout<<" unable to cach data in artist... terminating..."<<std::endl;
    exit(1);

}
std::string Artist::realName(){
    //so we have a jsondataobject. we then need to get the data out of the pair and into the child class
    // if this acessor has already been cashed then return variable stored. other wise cach variable then return.
    if( cachedRealName ){
        return _realName;
    }else{
        // otherwise we search the listofdataItems to see if one of the pairs key attributes match this atribute.
        for(int counter = 0; counter < listOfDataItems()->size(); counter++){
            if(listOfDataItems()->at(counter)->attributeName() == "real_name"){
                _realName = listOfDataItems()->at(counter)->stringValue();
                cachedRealName = true;
                return _realName;
            }

        }
        // if we find it then we set cached to true and set _profile to the profile value in that pair.
    }
    std::cout<<" unable to cach data in artist... terminating..."<<std::endl;
    exit(1);

}
std::string Artist::numImages(){
    //so we have a jsondataobject. we then need to get the data out of the pair and into the child class
    // if this acessor has already been cashed then return variable stored. other wise cach variable then return.
    if( cachedNumImages ){
        return _numImages;
    }else{
        // otherwise we search the listofdataItems to see if one of the pairs key attributes match this atribute.
        for(int counter = 0; counter < listOfDataItems()->size(); counter++){
            if(listOfDataItems()->at(counter)->attributeName() == "num_images"){
                _numImages = listOfDataItems()->at(counter)->stringValue();
                cachedNumImages = true;
                return _numImages;
            }

        }
        // if we find it then we set cached to true and set _profile to the profile value in that pair.
    }
    std::cout<<" unable to cach data in artist... terminating..."<<std::endl;
    exit(1);

}  // since it's a string in the JSON file
unsigned   Artist::artistID(){
    //so we have a jsondataobject. we then need to get the data out of the pair and into the child class
    // if this acessor has already been cashed then return variable stored. other wise cach variable then return.
    if( cachedArtistID ){
        return _artistID;
    }else{
        // otherwise we search the listofdataItems to see if one of the pairs key attributes match this atribute.
        for(int counter = 0; counter < listOfDataItems()->size(); counter++){
            if(listOfDataItems()->at(counter)->attributeName() == "artist_id"){
                _artistID = listOfDataItems()->at(counter)->intValue();
                cachedArtistID = true;
                return _artistID;
            }

        }
        // if we find it then we set cached to true and set _profile to the profile value in that pair.
    }
    std::cout<<" unable to cach data in artist... terminating..."<<std::endl;
    exit(1);

}

void Artist::print(){
    std::cout<<std::endl;
    std::cout<<"============================================================"<<std::endl;
    std::cout<< "name: "<< artistName()<<std::endl;
    std::cout<< "realName: "<< realName()<<std::endl;
    std::cout<< "profile: "<< profile()<<std::endl;
    std::cout<< "numImages "<< numImages()<<std::endl;
    std::cout<< "artist_iD: "<<artistID()<<std::endl;

    std::cout<<"============================================================"<<std::endl;
    std::cout<<std::endl;
}

std::string Artist::htmlString(){
    std:: string generatedHTML = "";
    std:: string ArtistImageTag = "";
    std:: string AlbumsFormatted = "";
    if(primaryImage() != nullptr){
        ArtistImageTag = primaryImage()->htmlString();
    }else if(secondaryImage() != nullptr) {
        ArtistImageTag = secondaryImage()->htmlString();
    }else{
        // if the object does not have a primary or secondary image then we ignore it.
        return "";
    }
    generatedHTML += TH("h2", artistName(), 0);
    generatedHTML += "\n";
    generatedHTML += ArtistImageTag;
    generatedHTML += "\n";
    generatedHTML += TH("table", TH("tr", TH("td", "Number of Images:", 2) +TH("td", numImages(), 3), 0) +TH("tr", TH("td", "profile:", 0) + TH("td",profile(),3), 0), 1);
    generatedHTML += "\n";
    generatedHTML +=TH("div","&nbsp;",4);
    generatedHTML += "\n";
    generatedHTML += TH("h2","Tracks",0);
    generatedHTML += "\n";
    for(int index = 0;index <_albums->numAlbums();index ++){
        AlbumsFormatted += _albums->listOfAlbums()->at(index)->htmlString(artistName());
    }
    generatedHTML += "\n";
    generatedHTML += TH("ol",TH("table",AlbumsFormatted,1),0);
    generatedHTML += "\n";



    return generatedHTML;
}

std::string Artist::TH(std::string tagName, std::string interior, int format){
    std::string encap = "";
    if(format == 1) {
        encap += "<"+tagName+" class=\"artistInfo\">";
        encap += interior;
        encap += "</"+tagName+">";
    }else if(format == 2) {
        encap += "<"+tagName+" class=\"tagName\">";
        encap += interior;
        encap += "</"+tagName+">";
    }else if(format == 3) {
        encap += "<"+tagName+" class=\"value\">";
        encap += interior;
        encap += "</"+tagName+">";
    }else if(format == 4) {
        encap += "<"+tagName+" class=\"Clear\">";
        encap += interior;
        encap += "</"+tagName+">";
    }else{
            encap += "<"+tagName+">";
            encap += interior;
            encap += "</"+tagName+">";

    }
    return encap;
}

