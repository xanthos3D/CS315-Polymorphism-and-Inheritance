//
// Created by xmani on 5/5/2023.
//

#ifndef PROJECT_4_ARTISTIMAGE_HPP
#define PROJECT_4_ARTISTIMAGE_HPP

#include "JSONDataObject.hpp"

class ArtistImage: public JSONDataObject{
public:
    ArtistImage();
    ~ArtistImage();

    std::string type();
    unsigned width();
    unsigned artistID();
    unsigned height();
    std::string uri();

    void print();
    std::string htmlString();
    std::string tagHelper1(std::string tagName,std::string interior, int format);


private:
    std::string _type, _uri;
    unsigned _artistID, _width, _height;
    bool cachedType, cachedUri, cachedArtistID, cachedWidth, cachedHeight;

};


#endif //PROJECT_4_ARTISTIMAGE_HPP
