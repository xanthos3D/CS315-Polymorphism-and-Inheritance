//
// Created by xmani on 5/7/2023.
//

#include "AlbumImages.hpp"
//#include "Artist.hpp"
#include <iostream>
#include <fstream>
#include<vector>

AlbumImages::AlbumImages(){
    //_AlbumImages = new std::vector<AlbumImage *>();
    //albumsVector = new tracks();
}
AlbumImages::~AlbumImages(){
    //delete _AlbumImages;
}

void AlbumImages::loadAlbumImageFromFile(std::string fileName){
    Tokenizer *tokenizer = new Tokenizer(fileName);
    parseJSONArray(tokenizer);
    delete tokenizer;

    // fills the container vector with proper artists objects.
    // is temperorary fix until i figure out how ot use listOfArtists()
    /*for (int index = 0; index < _listOfDataObjects->size(); index++) {
        //makes a new artist memory location
        AlbumImage *albumImage = new AlbumImage();
        //sets variable to the memory adress of a Jsondata object within _listifdataobjects
        albumImage->setlistOfDataItems(_listOfDataObjects->at(index)->listOfDataItems());
        _AlbumImages->push_back(albumImage);
        //artistImage->print();

    }*/

}
// keeps tracvk of the number of artist objects in the datatype
int AlbumImages::numAlbumImages(){
    //return _artists->size();
    return _listOfDataObjects->size();
}
// adds a artist to the container class
void AlbumImages::addAlbumImage(AlbumImage *AlbumImage){
    listOfAlbumImages()->push_back(AlbumImage);
    //listOfArtists()->push_back(artist)
}
// not sure what this does yet. keeps track of artists with proper id's?
