//
// Created by xmani on 4/22/2023.
//

#include "Pair.hpp"
#include<string>
#include<iostream>
#include"Token.hpp"



Pair::Pair(std::string attributeName, std::string attributeValue){

    _attributeName = attributeName;
    _isNumber = false;
    _attributeStringValue = attributeValue;
    _attributeNumberValue = 0;

}
Pair::Pair(std::string attributeName, int numberValue){

    _attributeName = attributeName;
    _isNumber = true;
    _attributeNumberValue = numberValue;
    _attributeStringValue = "";

}
bool Pair::isNumber(){
 return _isNumber;
}// is the datatype of the value of this entity integer?
int Pair::numberValue(){
    return _attributeNumberValue;

}
std::string Pair::stringValue(){
    return _attributeStringValue;
}
int Pair::intValue() {
    return _attributeNumberValue;
}

std::string Pair::attributeName(){
    return _attributeName;
}
// rewrite
void Pair::parsePair(Tokenizer *tokenizer){

    Token token;
    // loops through to get a single pair in tokenizer.
    while(!token.isClosingComa() && !token.isClosedCurlyBrace()){
        //gets token from tokenizer
        token = tokenizer->getToken();
        tokenizer->addTokenToVector(token);
        //token.print();

        if(token.isQuote()){
            token = tokenizer->getToken();
            tokenizer->addTokenToVector(token);
            //token.print();
            if(token.isAttributeValueString()){
                _attributeName = token.getStringValue();
                token = tokenizer->getToken();
                tokenizer->addTokenToVector(token);
                //token.print();
            }else{
                std::cout<<"No String Value After First Quote... Terminating...";
                exit(1);
            }
            if(token.isQuote()){
                token = tokenizer->getToken();
                tokenizer->addTokenToVector(token);
                //token.print();
            }else{
                std::cout<<"No Quote After String Value... Terminating...";
                exit(1);
            }

            if(token.isColon()){
                token = tokenizer->getToken();
                tokenizer->addTokenToVector(token);
                //token.print();
                if(token.isQuote()){
                    token = tokenizer->getToken();
                    tokenizer->addTokenToVector(token);
                    //token.print();
                    _attributeStringValue = token.getStringValue();

                }else if(token.isAttributeValueInt()){
                    _isNumber = true;
                    _attributeNumberValue = token.getIntValue();
                }else{
                    std::cout<<"improper token found after colon... terminating";
                    exit(1);
                }
                token = tokenizer->getToken();
                tokenizer->addTokenToVector(token);
                //token.print();

            }else{
            std::cout<<"No Colon After Quote... Terminating...";
            exit(1);
            }
        }

    }

}
