//
// Created by Owner on 4/12/2023.
//

#ifndef PROJECT_4_ALBUMS_HPP
#define PROJECT_4_ALBUMS_HPP
#include<vector>
#include<fstream>
#include<cstring>
#include"JSONArray.hpp"
#include "Album.hpp"
//#include "albumImage.hpp"
#include "AlbumImages.hpp"
//#include "Track.hpp"
//#include "Tracks.hpp"


class Albums: public JSONArray
{
public:
    Albums();
    ~Albums();

    int numAlbums();
    void addAlbum(Album *album);
    //Album *albumWithID(unsigned int aID);
    void loadAlbumsFromFile(std::string fileName);
    void htmlString();
    JSONDataObject *jsonObjectNode() { return new Album();  }
    void setTracksForAlbums(Tracks *tracks);
    void setImagesForAlbums(AlbumImages *);
    std::vector<Album *> *listOfAlbums() { return (std::vector<Album *> *) _listOfDataObjects; }

    void runAsserts();  // used for checking the integrity of this class.
private:
    // is temporary until i figure out listofalbums()
    //std::vector<Album *> *containerAlbums;


};


#endif //PROJECT_4_ALBUMS_HPP
