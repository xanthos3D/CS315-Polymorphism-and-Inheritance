//
// Created by xmani on 4/22/2023.
//

#include "JSONArray.hpp"
#include "JSONDataObject.hpp"
#include "Token.hpp"
#include <iostream>

JSONArray::JSONArray() {

    _listOfDataObjects = new std::vector<JSONDataObject *>();
}
JSONArray::~JSONArray(){
    delete _listOfDataObjects;
}
int JSONArray::numJSONObjects(){
return _listOfDataObjects->size();
}
void JSONArray::parseJSONArray(Tokenizer *tokenizer){
//JSONDataObject *jsonObjectNode() { return new Artist();  }
Token token;
    while(!token.isClosedBrace()){

        JSONDataObject* temp =  jsonObjectNode();
        temp->parseDataObject(tokenizer);
        token = tokenizer->getLatestTokenInVector();
        //token.print();
        tokenizer->addTokenToVector(token);
        _listOfDataObjects->push_back(temp);
        token = tokenizer->getToken();
        //token.print();
        tokenizer->addTokenToVector(token);

        //token = tokenizer->getToken();
        // running int a problem where it catches in this statement at the end of the data elements when it should not.
        if( !token.isClosedBrace() && !token.isClosingComa()  && !token.isClosedCurlyBrace() && !token.isEOF()){
            std::cout<<"token found out of order when parsing in JSONarray... Terminating...";
            exit(1);

        }
    }

}
void JSONArray::print(){

}
