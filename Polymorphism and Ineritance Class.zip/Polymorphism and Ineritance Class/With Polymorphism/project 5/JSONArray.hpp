//
// Created by xmani on 4/22/2023.
//

#ifndef PROJECT_4_JSONARRAY_HPP
#define PROJECT_4_JSONARRAY_HPP
#include<vector>
#include"JSONDataObject.hpp"


class JSONArray {
public:
    JSONArray();
    ~JSONArray();
    std::vector<JSONDataObject *> *listOfDataObjects() { return _listOfDataObjects; }
    virtual JSONDataObject *jsonObjectNode() = 0; // makes it so that this class cann not have a instance directly created.
    int numJSONObjects(); // what specifically is this supost to keep track of
    void parseJSONArray(Tokenizer *tokenizer);
    virtual void print();

protected:
    std::vector<JSONDataObject *> *_listOfDataObjects;

};


#endif //PROJECT_4_JSONARRAY_HPP
