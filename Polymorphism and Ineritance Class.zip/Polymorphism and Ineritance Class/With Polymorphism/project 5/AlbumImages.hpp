//
// Created by xmani on 5/7/2023.
//

#ifndef PROJECT_4_ALBUMIMAGES_HPP
#define PROJECT_4_ALBUMIMAGES_HPP


#include "JSONArray.hpp"
#include "AlbumImage.hpp"

class AlbumImages:public JSONArray {
public:
    AlbumImages();
    ~AlbumImages();

    int numAlbumImages();
    void addAlbumImage(AlbumImage *artistImage);
    //AlbumImage *AlbumImageWithID(unsigned int aID);
    void loadAlbumImageFromFile(std::string fileName);
    //std::string htmlString();
    JSONDataObject *jsonObjectNode() { return new AlbumImage();  }
    //void setAlbumsForArtists(ArtistImages *artistImages);
    //void setImagesForArtists(ArtistImage *);
    std::vector<AlbumImage *> *listOfAlbumImages() { return (std::vector<AlbumImage *> *) _listOfDataObjects; }
    //void runAsserts();  // used for checking the integrity of this class.
private:
    // had problems using listOfArtists so i made a second storage containter initilizing artists as there proper object from the jsondata objects.
    // should remove later but for now i am going to format it this way to continue the project.
    //std::vector<AlbumImage *> *_AlbumImages;
};


#endif //PROJECT_4_ALBUMIMAGES_HPP
