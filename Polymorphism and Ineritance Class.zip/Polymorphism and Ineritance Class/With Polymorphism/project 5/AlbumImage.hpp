//
// Created by xmani on 5/5/2023.
//

#ifndef PROJECT_4_ALBUMIMAGE_HPP
#define PROJECT_4_ALBUMIMAGE_HPP


#include "JSONDataObject.hpp"

class AlbumImage: public JSONDataObject{
public:
    AlbumImage();
    ~AlbumImage();

    std::string type();
    unsigned width();
    unsigned AlbumID();
    unsigned height();
    std::string uri();

    void print();
    std::string htmlString();
    std::string tagHelper1(std::string tagName,std::string interior, int format);


private:
    std::string _type, _uri;
    unsigned _AlbumID, _width, _height;
    bool cachedType, cachedUri, cachedAlbumID, cachedWidth, cachedHeight;

};


#endif //PROJECT_4_ALBUMIMAGE_HPP
