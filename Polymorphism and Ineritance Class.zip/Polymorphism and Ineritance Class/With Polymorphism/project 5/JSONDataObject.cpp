//
// Created by xmani on 4/22/2023.
//


#include "JSONDataObject.hpp"
#include "Pair.hpp"
#include <iostream>
#include "Tokenizer.hpp"
//#include "Token.cpp"

JSONDataObject::JSONDataObject(){
_listOfDataItems = new  std::vector<Pair *>();
}
JSONDataObject::~JSONDataObject(){
    // may need to have a loop deleting the pointers to pair as well?
    delete _listOfDataItems;

}
void JSONDataObject::setlistOfDataItems(std::vector<Pair *> *temp){
    _listOfDataItems = temp;
}

void JSONDataObject::parseDataObject(Tokenizer *tokenizer){


    std::vector<Pair> dataItems;

    std::string temp = "";
    Token token;

    while( tokenizer->vectorIsEmpty() || !tokenizer->getLatestTokenInVector().isClosedCurlyBrace()){
        Pair* tempPair = new Pair("","");
        tempPair->parsePair(tokenizer);
        temp = tempPair->attributeName();
        if(tempPair->isNumber()){
            Pair* tempPair1 = new Pair(tempPair->attributeName(),tempPair->intValue());
            _listOfDataItems->push_back(tempPair1);
            //std::cout<<"attribute name: "<< tempPair1->attributeName()<<" ";
            //std::cout<<"int name: "<< tempPair1->intValue()<<std::endl;
        }else{
            _listOfDataItems->push_back(tempPair);
            //std::cout<<"attribute name: "<< tempPair->attributeName()<<" ";
            //std::cout<<"string name: "<< tempPair->stringValue()<<std::endl;
        }
    }

    //std::cout<<"==========================================="<<std::endl;
    //print();

}
void JSONDataObject::print() {

    for(int index = 0; index < _listOfDataItems->size();index++){
        std::cout<<"Attribute value: " <<_listOfDataItems->at(index)->attributeName()<<" |-| ";
        if(_listOfDataItems->at(index)->isNumber()) {
            std::cout<<"int value: " <<_listOfDataItems->at(index)->intValue()<<std::endl;
        }else {
            std::cout<<"string value: " <<_listOfDataItems->at(index)->stringValue()<<std::endl;
        }


    }
}




