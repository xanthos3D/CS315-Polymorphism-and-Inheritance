//
// Created by Owner on 4/12/2023.
//

#include "Albums.hpp"
#include "Album.hpp"
#include <iostream>
#include <fstream>
#include<vector>
#include "Tracks.hpp"
//#include "AlbumImages.hpp"

Albums::Albums(){
    //listOfAlbums() = new std::vector<Album *>();
}
Albums::~Albums(){

}

void Albums::loadAlbumsFromFile(std::string fileName){
    Tokenizer *tokenizer = new Tokenizer(fileName);
    parseJSONArray(tokenizer);
    delete tokenizer;

    // fills the container vector with proper artists objects.
    // is temperorary fix until i figure out how to use listOfArtists()
    /*for (int index = 0; index < _listOfDataObjects->size(); index++) {
        //makes a new artist memory location
        Album *album = new Album();
        //sets variable to the memory adress of a Jsondata object within _listifdataobjects
        album->setlistOfDataItems(_listOfDataObjects->at(index)->listOfDataItems());
        listOfAlbums()->push_back(album);
        //album->print();

    }*/

}
// keeps tracvk of the number of artist objects in the datatype
int Albums::numAlbums(){
    return _listOfDataObjects->size();
    // return _listOfDataObjects->size();
}
// adds a artist to the container class
void Albums::addAlbum(Album *album){
    listOfAlbums()->push_back(album);
}
// not sure what this does yet. keeps track of artists with proper id's?

//generates the html string file.
void Albums::htmlString() {
    for(int index = 0;index <listOfAlbums()->size();index ++){
            listOfAlbums()->at(index)->htmlStringAlbum();
    }


}

void Albums::setTracksForAlbums(Tracks *tracks){
    // nested for loops looking to set albums to artis objects
    for(int index1 = 0; index1 < listOfAlbums()->size();index1++){
        Tracks* fillAlbumsTracks = new Tracks();
        for(int index2 = 0; index2 < tracks->listOfTracks()->size();index2++){
            //std::cout<<" does this -> "<<listOfAlbums()->at(index1)->albumID()<<" match this->"<< tracks->listOfTracks()->at(index2)->albumID()<<std::endl;
            if(listOfAlbums()->at(index1)->albumID() == tracks->listOfTracks()->at(index2)->albumID()){
                //std::cout<<"yes it does"<<std::endl;
                Track* currentTrack = tracks->listOfTracks()->at(index2);
                fillAlbumsTracks->addTrack(currentTrack);
            }

        }
        listOfAlbums()->at(index1)->setTracks(fillAlbumsTracks);
    }
}
void Albums::setImagesForAlbums(AlbumImages * albumImages){
    for(int index1 = 0; index1 < listOfAlbums()->size();index1++){
        //Albums* fillArtistAlbums = new Albums();
        for(int index2 = 0; index2 < albumImages->numAlbumImages();index2++){
            //std::cout<<"does this-> "<< _artists->at(index1)->artistID()<< " match this?->"<< artistImages->listOfArtistImages()->at(index2)->artistID()<<std::endl;
            if(listOfAlbums()->at(index1)->albumID() == albumImages->listOfAlbumImages()->at(index2)->AlbumID()){
                if(albumImages->listOfAlbumImages()->at(index2)->type() == "primary"){
                    AlbumImage* currentAlbumImage = albumImages->listOfAlbumImages()->at(index2);
                    listOfAlbums()->at(index1)->setPrimaryImage(currentAlbumImage);
                }else if(albumImages->listOfAlbumImages()->at(index2)->type() == "secondary"){
                    AlbumImage* currentAlbumImage = albumImages->listOfAlbumImages()->at(index2);
                    listOfAlbums()->at(index1)->setSecondImage(currentAlbumImage);
                }
                //fillArtistAlbums->addAlbum(currentAlbum);
            }

        }
        //_artists->at(index1)->setAlbums(fillArtistAlbums);
    }

}

// function for testing purposes.
void Albums::runAsserts(){

}  // used for checking the integrity of this class.