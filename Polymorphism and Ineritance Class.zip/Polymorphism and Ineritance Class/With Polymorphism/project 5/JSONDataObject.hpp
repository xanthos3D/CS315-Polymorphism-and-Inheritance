//
// Created by xmani on 4/22/2023.
//

#ifndef PROJECT_4_JSONDATAOBJECT_HPP
#define PROJECT_4_JSONDATAOBJECT_HPP
#include"Pair.hpp"
#include<vector>

/*
 * The next object of interest is a C++ data-type that represents a JSON data-object. Of course,
 * our JSON data-objects may contain attributes for an artist, an album, or a track. However,
 * that information is not relevant at this level of abstraction. That is, the C++ data-type that
 * we will write to represent a JSON object is not concerned with the type of the entity that it represents;
 * it views it as a collection of attribute-key/value items. Here is a header-file for it.*/

// this hold a object of the json data? it is part of the super class as it doesn't care exactly whats stored here just that its a object of the pairs class?


class JSONDataObject {
public:
    JSONDataObject();
    virtual ~JSONDataObject();
    std::vector<Pair *> *listOfDataItems() { return _listOfDataItems; }
    void setlistOfDataItems(std::vector<Pair *> *temp);
    void parseDataObject(Tokenizer *tokenizer);
    virtual void print();


private:
    // stores the pair tokens.
    std::vector<Pair *> *_listOfDataItems;
};


#endif //PROJECT_4_JSONDATAOBJECT_HPP
