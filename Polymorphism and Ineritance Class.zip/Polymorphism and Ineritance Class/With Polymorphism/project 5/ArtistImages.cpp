//
// Created by xmani on 5/7/2023.
//

#include "ArtistImages.hpp"
#include "Artist.hpp"
#include <iostream>
#include <fstream>
#include<vector>

ArtistImages::ArtistImages(){
    //_ArtistImages = new std::vector<ArtistImage *>();
    //albumsVector = new tracks();
}
ArtistImages::~ArtistImages(){
   //delete _ArtistImages;
}

void ArtistImages::loadArtistImageFromFile(std::string fileName){
    Tokenizer *tokenizer = new Tokenizer(fileName);
    parseJSONArray(tokenizer);
    delete tokenizer;

    // fills the container vector with proper artists objects.
    // is temperorary fix until i figure out how ot use listOfArtists()
    /*for (int index = 0; index < _listOfDataObjects->size(); index++) {
        //makes a new artist memory location
        ArtistImage *artistImage = new ArtistImage();
        //sets variable to the memory adress of a Jsondata object within _listifdataobjects
        artistImage->setlistOfDataItems(_listOfDataObjects->at(index)->listOfDataItems());
        _ArtistImages->push_back(artistImage);
        //artistImage->print();

    }*/

}
// keeps tracvk of the number of artist objects in the datatype
int ArtistImages::numArtistImages(){
    //return _artists->size();
    return _listOfDataObjects->size();
}
// adds a artist to the container class
void ArtistImages::addArtistImage(ArtistImage *artistImage){
    listOfArtistImages()->push_back(artistImage);
    //listOfArtists()->push_back(artist)
}
// not sure what this does yet. keeps track of artists with proper id's?
//generates the html string file.

