//
// Created by Owner on 4/12/2023.
//

#include "Artists.hpp"
#include "Artist.hpp"
#include <iostream>
#include <fstream>
#include<vector>

Artists::Artists(){
            //listOfArtists() = new std::vector<Artist *>();
            //albumsVector = new tracks();
}
Artists::~Artists(){

}

void Artists::loadArtistsFromFile(std::string fileName){
    Tokenizer *tokenizer = new Tokenizer(fileName);
    parseJSONArray(tokenizer);
    delete tokenizer;

    // fills the container vector with proper artists objects.
    // is temperorary fix until i figure out how ot use listOfArtists()
    /*for (int index = 0; index < _listOfDataObjects->size(); index++) {
        //makes a new artist memory location
        Artist *artist = new Artist();
        //sets variable to the memory adress of a Jsondata object within _listifdataobjects
        artist->setlistOfDataItems(_listOfDataObjects->at(index)->listOfDataItems());
        listOfArtists()->push_back(artist);
        //artist->print();

    }*/

}
// keeps tracvk of the number of artist objects in the datatype
int Artists::numArtists(){
    //return listOfArtists()->size();
     return _listOfDataObjects->size();
}
// adds a artist to the container class
void Artists::addArtist(Artist *artist){
    listOfArtists()->push_back(artist);
   //listOfArtists()->push_back(artist)
}
// not sure what this does yet. keeps track of artists with proper id's?

//generates the html string file.
std::string Artists::htmlString() {


    //std::cout << "file we are going to read artists_template.html" << std::endl;
    std::fstream iStream1;
    iStream1.open("artists_template.html", std::ios::in);


    std::string wholeHtml = "";
    char c = ' ';
    // reads the template file until we hit the point where we need to fill data with our json objects
    while (!iStream1.eof()) {
        iStream1.get(c);
        /*if ((c != '<' && iStream1.peek() != '%') || (c != '%'  && iStream1.peek() != '>')) {
            wholeHtml += c;
        }*/if((c == '<' && iStream1.peek() == '%')){

        }else if ((c != '<' && iStream1.peek() != '%') || (c != '%'  && iStream1.peek() != '>')) {
                wholeHtml += c;
        }
        if (c == '<' && iStream1.peek() == '%') {


            for (int index = 0; index < listOfArtists()->size() ; index++) {
                wholeHtml += listOfArtists()->at(index)->htmlString();
            }

            //wholeHtml += listOfArtists()->at(0)->htmlString();

            // gets the rest of the template file after we put in all thedata from artists
            while (c != '>' ) {
                iStream1.get(c);
            }
        }

    }

    std::ofstream createHtml("artists-working.html");

    createHtml << wholeHtml;
    //std::cout<< wholeHtml;

    createHtml.close();
    iStream1.close();
    return wholeHtml;
}

void Artists::setAlbumsForArtists(Albums *albums){
    // nested for loops looking to set albums to artis objects
    for(int index1 = 0; index1 < listOfArtists()->size();index1++){
        Albums* fillArtistAlbums = new Albums();
        for(int index2 = 0; index2 < albums->listOfAlbums()->size();index2++){
            if(listOfArtists()->at(index1)->artistID() == albums->listOfAlbums()->at(index2)->artistID()){
                Album* currentAlbum = albums->listOfAlbums()->at(index2);
                fillArtistAlbums->addAlbum(currentAlbum);
            }

        }
        listOfArtists()->at(index1)->setAlbums(fillArtistAlbums);
    }
}
void Artists::setImagesForArtists(ArtistImages * artistImages){
    for(int index1 = 0; index1 < listOfArtists()->size();index1++){
        //Albums* fillArtistAlbums = new Albums();
        for(int index2 = 0; index2 < artistImages->numArtistImages();index2++){
            //std::cout<<"does this-> "<< listOfArtists()->at(index1)->artistID()<< " match this?->"<< artistImages->listOfArtistImages()->at(index2)->artistID()<<std::endl;
            if(listOfArtists()->at(index1)->artistID() == artistImages->listOfArtistImages()->at(index2)->artistID()){
                if(artistImages->listOfArtistImages()->at(index2)->type() == "primary"){
                    ArtistImage* currentArtistImage = artistImages->listOfArtistImages()->at(index2);
                    listOfArtists()->at(index1)->setPrimaryImage(currentArtistImage);
                }else if(artistImages->listOfArtistImages()->at(index2)->type() == "secondary"){
                    ArtistImage* currentArtistImage = artistImages->listOfArtistImages()->at(index2);
                    listOfArtists()->at(index1)->setSecondImage(currentArtistImage);
                }
                //fillArtistAlbums->addAlbum(currentAlbum);
            }

        }
        //listOfArtists()->at(index1)->setAlbums(fillArtistAlbums);
    }

}

// function for testing purposes.
void Artists::runAsserts(){

}  // used for checking the integrity of this class.
