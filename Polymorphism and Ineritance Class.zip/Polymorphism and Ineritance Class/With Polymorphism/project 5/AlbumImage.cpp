//
// Created by xmani on 5/5/2023.
//

#include "AlbumImage.hpp"
#include<iostream>
#include<string>
#include<cstring>

AlbumImage::AlbumImage(){
    _type= "";
    _uri = "";
    _AlbumID = 0;
    _width = 0;
    _height  = 0;
    cachedType = false;
    cachedUri= false;
    cachedWidth= false;
    cachedHeight= false;
    cachedAlbumID= false;
}
AlbumImage::~AlbumImage(){

}

std::string AlbumImage::type(){
    if( cachedType ){
        return _type;
    }else{
        // otherwise we search the listofdataItems to see if one of the pairs key attributes match this atribute.
        for(int counter = 0; counter < listOfDataItems()->size(); counter++){
            if(listOfDataItems()->at(counter)->attributeName() == "type"){
                _type = listOfDataItems()->at(counter)->stringValue();
                cachedType = true;
                return _type;
            }

        }
        // if we find it then we set cached to true and set _profile to the profile value in that pair.
    }
    std::cout<<" unable to cach data in albumImage... terminating..."<<std::endl;
    exit(1);

}
std::string AlbumImage::uri(){
    if( cachedUri ){
        return _uri;
    }else{
        // otherwise we search the listofdataItems to see if one of the pairs key attributes match this atribute.
        for(int counter = 0; counter < listOfDataItems()->size(); counter++){
            if(listOfDataItems()->at(counter)->attributeName() == "uri"){
                _uri = listOfDataItems()->at(counter)->stringValue();
                cachedUri = true;
                return _uri;
            }

        }
        // if we find it then we set cached to true and set _profile to the profile value in that pair.
    }
    std::cout<<" unable to cach data in albumImage... terminating..."<<std::endl;
    exit(1);
}
unsigned AlbumImage::width(){
    if( cachedWidth ){
        return _width;
    }else{
        // otherwise we search the listofdataItems to see if one of the pairs key attributes match this atribute.
        for(int counter = 0; counter < listOfDataItems()->size(); counter++){
            if(listOfDataItems()->at(counter)->attributeName() == "width"){
                _width = listOfDataItems()->at(counter)->intValue();
                cachedWidth = true;
                return _width;
            }

        }
        // if we find it then we set cached to true and set _profile to the profile value in that pair.
    }
    std::cout<<" unable to cach data in albumImage... terminating..."<<std::endl;
    exit(1);

}
unsigned AlbumImage::height(){
    if( cachedHeight ){
        return _height;
    }else{
        // otherwise we search the listofdataItems to see if one of the pairs key attributes match this atribute.
        for(int counter = 0; counter < listOfDataItems()->size(); counter++){
            if(listOfDataItems()->at(counter)->attributeName() == "height"){
                _height = listOfDataItems()->at(counter)->intValue();
                cachedHeight = true;
                return _height;
            }

        }
        // if we find it then we set cached to true and set _profile to the profile value in that pair.
    }
    std::cout<<" unable to cach data in albumImage... terminating..."<<std::endl;
    exit(1);

}
unsigned AlbumImage::AlbumID(){
    if( cachedAlbumID ){
        return _AlbumID;
    }else{
        // otherwise we search the listofdataItems to see if one of the pairs key attributes match this atribute.
        for(int counter = 0; counter < listOfDataItems()->size(); counter++){
            if(listOfDataItems()->at(counter)->attributeName() == "album_id"){
                _AlbumID = listOfDataItems()->at(counter)->intValue();
                cachedAlbumID = true;
                return _AlbumID;
            }

        }
        // if we find it then we set cached to true and set _profile to the profile value in that pair.
    }
    std::cout<<" unable to cach data in albumImage... terminating..."<<std::endl;
    exit(1);

}

void AlbumImage::print(){
    std::cout<<std::endl;
    std::cout<<"============================================================"<<std::endl;
    std::cout<< "type: "<< type()<<std::endl;
    std::cout<< "width: "<< width()<<std::endl;
    std::cout<< "artist id: "<< AlbumID()<<std::endl;
    std::cout<< "height: "<< height()<<std::endl;
    std::cout<< "uri: "<< uri()<<std::endl;

    std::cout<<"============================================================"<<std::endl;
    std::cout<<std::endl;
}




std::string AlbumImage::htmlString(){
    std:: string generatedHTML = "<img class=\"image\" width= "+ std::to_string(width()/2)+" height="+std::to_string(height()/2)+" src=\""+uri()+"\">";

    return generatedHTML;
}

std::string AlbumImage::tagHelper1(std::string tagName,std::string interior, int format){
    std::string encap = "";
    if(format == 1){
        encap += "<"+tagName+">";
        encap += interior;
        encap += "\n  </"+tagName+">\n";

    }else if(format == 2){
        encap += "<"+tagName+">\n";
        encap += interior;
        encap += "     </"+tagName+">";

    }else{
        encap += "<"+tagName+">";
        encap += interior;
        encap += "</"+tagName+">";
    }
    return encap;
}