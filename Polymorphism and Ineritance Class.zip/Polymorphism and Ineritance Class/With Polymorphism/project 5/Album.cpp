//
// Created by xmani on 4/8/2023.
//

#include "Album.hpp"

#include<iostream>
#include<string>
#include<cstring>
#include<stdlib.h>
#include "Tracks.hpp"

Album::Album(){
 _title = "";
 _genres = "";
 _year = "";
 _albumID = 0;
 _artistID = 0;
 _numTracks = 0;
 _numImages = 0;
 cachedAlbumID = false;
 cachedArtistID = false;
 cachedGenres = false;
 cachedNumImages = false;
 cachedNumTracks = false;
 cachedTitle = false;
 cachedYear = false;
 _primaryAlbumImage = nullptr;
 _secondaryAlbumImage = nullptr;

}

Album::~Album(){

}
std::string Album::title(){
    if( cachedTitle ){
        return _title;
    }else{
        // otherwise we search the listofdataItems to see if one of the pairs key attributes match this atribute.
        for(int counter = 0; counter < listOfDataItems()->size(); counter++){
            if(listOfDataItems()->at(counter)->attributeName() == "title"){
                _title = listOfDataItems()->at(counter)->stringValue();
                cachedTitle = true;
                return _title;
            }

        }
        // if we find it then we set cached to true and set _profile to the profile value in that pair.
        std::cout<<" unable to cach data in album... terminating..."<<std::endl;
        exit(1);
    }
}
unsigned Album::albumID(){
    if( cachedAlbumID ){
        return _albumID;
    }else{
        // otherwise we search the listofdataItems to see if one of the pairs key attributes match this atribute.
        for(int counter = 0; counter < listOfDataItems()->size(); counter++){
            if(listOfDataItems()->at(counter)->attributeName() == "album_id"){
                _albumID = listOfDataItems()->at(counter)->intValue();
                cachedAlbumID = true;
                return _albumID;
            }

        }
        // if we find it then we set cached to true and set _profile to the profile value in that pair.
    }
    std::cout<<" unable to cach data in album... terminating..."<<std::endl;
    exit(1);
}
unsigned Album::numImages(){
    if( cachedNumImages ){
        return _numImages;
    }else{
        // otherwise we search the listofdataItems to see if one of the pairs key attributes match this atribute.
        for(int counter = 0; counter < listOfDataItems()->size(); counter++){
            if(listOfDataItems()->at(counter)->attributeName() == "num_images"){
                _numImages = listOfDataItems()->at(counter)->intValue();
                cachedNumImages = true;
                return _numImages;
            }

        }
        // if we find it then we set cached to true and set _profile to the profile value in that pair.
    }
    std::cout<<" unable to cach data in album... terminating..."<<std::endl;
    exit(1);
}
unsigned Album::numTracks(){
    if( cachedNumTracks ){
        return _numTracks;
    }else{
        // otherwise we search the listofdataItems to see if one of the pairs key attributes match this atribute.
        for(int counter = 0; counter < listOfDataItems()->size(); counter++){
            if(listOfDataItems()->at(counter)->attributeName() == "num_tracks"){
                _numTracks = listOfDataItems()->at(counter)->intValue();
                cachedNumTracks = true;
                return _numTracks;
            }

        }
        // if we find it then we set cached to true and set _profile to the profile value in that pair.
    }
    std::cout<<" unable to cach data in album... terminating..."<<std::endl;
    exit(1);
}
std::string Album::genres(){
    if( cachedGenres ){
        return _genres;
    }else{
        // otherwise we search the listofdataItems to see if one of the pairs key attributes match this atribute.
        for(int counter = 0; counter < listOfDataItems()->size(); counter++){
            if(listOfDataItems()->at(counter)->attributeName() == "genres"){
                _genres = listOfDataItems()->at(counter)->stringValue();
                cachedGenres = true;
                return _genres;
            }

        }
        // if we find it then we set cached to true and set _profile to the profile value in that pair.
    }
    std::cout<<" unable to cach data in album... terminating..."<<std::endl;
    exit(1);
}
std::string Album::year(){
    if( cachedYear ){
        return _year;
    }else{
        // otherwise we search the listofdataItems to see if one of the pairs key attributes match this atribute.
        for(int counter = 0; counter < listOfDataItems()->size(); counter++){
            if(listOfDataItems()->at(counter)->attributeName() == "year"){
                _year = listOfDataItems()->at(counter)->stringValue();
                cachedYear= true;
                return _year;
            }

        }
        // if we find it then we set cached to true and set _profile to the profile value in that pair.
    }
    std::cout<<" unable to cach data in album... terminating..."<<std::endl;
    exit(1);
}
unsigned Album::artistID(){
    if( cachedArtistID ){
        return _artistID;
    }else{
        // otherwise we search the listofdataItems to see if one of the pairs key attributes match this atribute.
        for(int counter = 0; counter < listOfDataItems()->size(); counter++){
            if(listOfDataItems()->at(counter)->attributeName() == "artist_id"){
                _artistID = listOfDataItems()->at(counter)->intValue();
                cachedArtistID= true;
                return _artistID;
            }

        }
        // if we find it then we set cached to true and set _profile to the profile value in that pair.
    }
    std::cout<<" unable to cach data in album... terminating..."<<std::endl;
    exit(1);
}

void Album::setTracks(Tracks *tracks) {
_tracks = tracks;
}

//}
void Album::print(){
    std::cout<<std::endl;
    std::cout<<"============================================================"<<std::endl;
    std::cout<< "num_tracks: "<< numTracks()<<std::endl;
    std::cout<< "title: "<< title()<<std::endl;
    std::cout<< "year: "<< year()<<std::endl;
    std::cout<< "genres: "<< genres()<<std::endl;
    std::cout<< "artist_id: "<<artistID()<<std::endl;
    std::cout<< "num_images: "<< numImages()<<std::endl;
    std::cout<< "album_id: "<< albumID()<<std::endl;
    std::cout<<"============================================================"<<std::endl;
    std::cout<<std::endl;

}







std::string Album::htmlString(std::string artistName){
    std:: string generatedHTML = "";
    std:: string interiorElements = "";
    std:: string AlbumImageTag = "";
    std:: string AlbumsFormatted = "";
    if(_primaryAlbumImage != nullptr){
        AlbumImageTag = _primaryAlbumImage->htmlString();
    }else if(_secondaryAlbumImage != nullptr) {
        AlbumImageTag = _secondaryAlbumImage->htmlString();
    }
    generatedHTML += "\n";
    generatedHTML += TH("li",TH("p",TH("strong",year(),0),0)+AlbumImageTag+
                                TH("table",TH("tr",TH("td",title(),5),0)+TH("tr",TH("td","Artist:",6)+TH("td",artistName,3),0)+
                                TH("tr",TH("td","Genres:",6)+TH("td",genres(),3),0)+
                                TH("tr",TH("td","Year:",6)+TH("td",year(),3),0),1)+TH("div","&nbsp;",4),0);
    generatedHTML += "\n";
    generatedHTML += TH("h2","Tracklist",0);
    generatedHTML += "\n";
    for(int index = 0;index <_tracks->numTracks();index ++){
        AlbumsFormatted += _tracks->listOfTracks()->at(index)->htmlString();
    }
    generatedHTML += "\n";
    generatedHTML += TH("li",TH("table",AlbumsFormatted,7),0);
    //generatedHTML += "\n";


    generatedHTML += "\n";

    generatedHTML = TH("div",generatedHTML,4);


    return generatedHTML;
}

std::string Album::htmlStringAlbum(){

    std:: string generatedHTML = "";
    std:: string interiorElements = "";
    std:: string AlbumImageTag = "";
    std:: string AlbumsFormatted = "";
    std::string artistName = "";
    if(_primaryAlbumImage != nullptr){
        AlbumImageTag = _primaryAlbumImage->htmlString();
    }else if(_secondaryAlbumImage != nullptr) {
        AlbumImageTag = _secondaryAlbumImage->htmlString();
    }

    if(!tracks()->listOfTracks()->empty()){
        artistName = tracks()->listOfTracks()->at(0)->artistName();
    }

    generatedHTML += "\n";
    generatedHTML += TH("li",TH("p",TH("strong",year(),0),0)+AlbumImageTag+
                             TH("table",TH("tr",TH("td",title(),5),0)+TH("tr",TH("td","Artist:",6)+TH("td",artistName,3),0)+
                                        TH("tr",TH("td","Genres:",6)+TH("td",genres(),3),0)+
                                        TH("tr",TH("td","Year:",6)+TH("td",year(),3),0),1)+TH("div","&nbsp;",4),0);
    generatedHTML += TH("h2","Tracklist",0);
    for(int index = 0;index <_tracks->numTracks();index ++){
        AlbumsFormatted += _tracks->listOfTracks()->at(index)->htmlString();
    }
    generatedHTML += TH("table",TH("tbody",AlbumsFormatted,0),7);
    //generatedHTML += "\n";

    generatedHTML += "\n";

    //std::cout << "file we are going to read artists_template.html" << std::endl;
    std::fstream iStream1;
    iStream1.open("album_template.html", std::ios::in);


    std::string wholeHtml = "";
    char c = ' ';
    // reads the template file until we hit the point where we need to fill data with our json objects
    while (!iStream1.eof()) {
        iStream1.get(c);
        /*if ((c != '<' && iStream1.peek() != '%') || (c != '%'  && iStream1.peek() != '>')) {
            wholeHtml += c;
        }*/if((c == '<' && iStream1.peek() == '%')){

        }else if ((c != '<' && iStream1.peek() != '%') || (c != '%'  && iStream1.peek() != '>')) {
            wholeHtml += c;
        }
        if (c == '<' && iStream1.peek() == '%') {


            wholeHtml += generatedHTML;

            // gets the rest of the template file after we put in all thedata from artists
            while (c != '>' ) {
                iStream1.get(c);
            }
        }

    }
   std::string path ="./html_albums/"+std::to_string(albumID())+".html";
    //std::cout<<"writing album to folder: "+path<<std::endl;
    std::ofstream createHtml(path);

    createHtml << wholeHtml;
    //std::cout<< wholeHtml;

    createHtml.close();
    iStream1.close();
    return wholeHtml;




 return generatedHTML;

}

std::string Album::TH(std::string tagName, std::string interior, int format){
    std::string encap = "";
    if(format == 1) {
        encap += "<"+tagName+" class=\"albumInfo\">";
        encap += interior;
        encap += "</"+tagName+">";
    }else if(format == 2) {
        encap += "<"+tagName+" class=\"tagName\">";
        encap += interior;
        encap += "</"+tagName+">";
    }else if(format == 3) {
        encap += "<"+tagName+" class=\"value\">";
        encap += interior;
        encap += "</"+tagName+">";
    }else if(format == 4) {
        encap += "<"+tagName+" class=\"clear\">";
        encap += interior;
        encap += "</"+tagName+">";
    }else if(format == 5) {
        encap += "<"+tagName+" class=\"aTitle\" colspan=2>";
        encap += interior;
        encap += "</"+tagName+">";
    }else if(format == 6) {
        encap += "<"+tagName+" class=\"tdNarrow\">";
        encap += interior;
        encap += "</"+tagName+">";
    }else if(format == 7) {
        encap += "<"+tagName+" class=\"tracks\">";
        encap += interior;
        encap += "</"+tagName+">";
    }else{
        encap += "<"+tagName+">";
        encap += interior;
        encap += "</"+tagName+">";

    }
    return encap;
}

