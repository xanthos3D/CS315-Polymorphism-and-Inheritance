//
// Created by xmani on 4/6/2023.
//


#include "Albums.hpp"
#include "Artists.hpp"
#include "Tracks.hpp"
#include <iostream>
#include<vector>
#include "ArtistImages.hpp"
#include "AlbumImages.hpp"



int main(int argc, char *argv[]){

    // this check increases with the amount of file we use
    if (argc != 6) {  // we expect the name of the file as an argument to the program.
        std::cout << "usage: " << argv[0] << " nameOfAnInputFile" << std::endl;
        exit(1);
    }

    // Here, we open the file to make sure that it exists before starting the program.
    // When using CLion, the input file has to be in cmake-build-debug directory.
    std::fstream inputStream;
    inputStream.open(argv[1], std::ios::in);    // open for reading
    if( ! inputStream.is_open()) {
        std::cout << "Unable top open " << argv[1] << ". Terminating...";
        //std::cout << strerror(errno) << std::endl;
        exit(2);
    }

    inputStream.close();

    inputStream.open(argv[2], std::ios::in);    // open for reading
    if( ! inputStream.is_open()) {
        std::cout << "Unable top open " << argv[2] << ". Terminating...";
        //std::cout << strerror(errno) << std::endl;
        exit(2);
    }

    inputStream.close();

    inputStream.open(argv[3], std::ios::in);    // open for reading
    if( ! inputStream.is_open()) {
        std::cout << "Unable top open " << argv[3] << ". Terminating...";
        //std::cout << strerror(errno) << std::endl;
        exit(2);
    }

    inputStream.close();

    inputStream.open(argv[4], std::ios::in);    // open for reading
    if( ! inputStream.is_open()) {
        std::cout << "Unable top open " << argv[4] << ". Terminating...";
        //std::cout << strerror(errno) << std::endl;
        exit(2);
    }

    inputStream.close();

    inputStream.open(argv[5], std::ios::in);    // open for reading
    if( ! inputStream.is_open()) {
        std::cout << "Unable top open " << argv[5] << ". Terminating...";
        //std::cout << strerror(errno) << std::endl;
        exit(2);
    }

    inputStream.close();

    Artists artistsArray1;
    artistsArray1.loadArtistsFromFile(argv[1]);

    ArtistImages* artistImagesArray = new ArtistImages();
    artistImagesArray->loadArtistImageFromFile(argv[2]);

    Albums* albumsArray1 = new Albums();
    albumsArray1->loadAlbumsFromFile(argv[3]);

    AlbumImages* albumImagesArray = new AlbumImages();
    albumImagesArray->loadAlbumImageFromFile(argv[4]);

    Tracks* tracksArray1 = new Tracks();
    tracksArray1->loadTracksFromFile(argv[5]);

    albumsArray1->setTracksForAlbums(tracksArray1);

    albumsArray1->setImagesForAlbums(albumImagesArray);

   artistsArray1.setAlbumsForArtists(albumsArray1);

   artistsArray1.setImagesForArtists(artistImagesArray);

   artistsArray1.htmlString();

   albumsArray1->htmlString();

    std::cout<< "end of program"<<std::endl;


//std::cout<<"testing"<<std::endl;

    return 0;
}
