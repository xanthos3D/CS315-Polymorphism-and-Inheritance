//
// Created by xmani on 4/22/2023.
//

#ifndef PROJECT_4_PAIR_HPP
#define PROJECT_4_PAIR_HPP

#include<string>
#include<fstream>
#include"Tokenizer.hpp"

/*
 *For example, an instance of this class would represent the following item.,"artist_name": "Beatles, The"
 * As the names of the functions indicate, once this class parses an item, it would be able to provide access
 * to the name of the attribute and its value. Of course, the value of an attribute can be a number or a string.
 * Since this class parses the input, it knows the data-type of the value of the attribute and provides access to
 * that information, if asked to do so.*/
//class which open up the file for use.

class Pair {
    // represents a entity and its value:

public:
    Pair(std::string attributeName, std::string attributeValue);
    Pair(std::string attributeName, int numberValue);
    bool isNumber();  // is the datatype of the value of this entity integer?
    int numberValue();
    std::string stringValue();
    int intValue();
    std::string attributeName();
    void parsePair(Tokenizer *tokenizer);

private:
    std::string _attributeName, _attributeStringValue;
    int _attributeNumberValue;
    bool _isNumber;

};


#endif //PROJECT_4_PAIR_HPP
